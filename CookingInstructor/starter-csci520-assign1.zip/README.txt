<Please submit this file with your solution.>

CSCI 520, Assignment 1

<Your name>

================

<Description of what you have accomplished>
<Also, explain any extra credit that you have implemented.>

